CREATE OR ALTER PROCEDURE GEN_SISMPRO_Obtener
    @cCodPro CHAR(12)
AS
BEGIN
    SELECT  
        cCodPro,
        cTipInv,
        cNomPro,
        cNomCor,
        cFabric,
        cTurno,
        cArea,
        cSeccio,
        cGrupo,
        nOrden,
        cEstado,
        nCosPro,
        nPreVen,
        nPreMay,
        nDuraci,
        dfeccre,
        ccodusu,
        dFecMod,
        cSisOpe
    FROM [dbo].[SISMPRO]
    WHERE cCodPro = @cCodPro;
END;