CREATE OR ALTER PROCEDURE GEN_SISMPRO_Actualizar
    @cCodPro CHAR(12),
    @cTipInv CHAR(1),
    @cNomPro VARCHAR(150),
    @cNomCor CHAR(25),
    @cFabric CHAR(3),
    @cTurno CHAR(1),
    @cArea CHAR(1),
    @cSeccio CHAR(1),
    @cGrupo CHAR(2),
    @nOrden INT,
    @cEstado CHAR(1),
    @nCosPro DECIMAL(18,2),
    @nPreVen DECIMAL(18,2),
    @nPreMay DECIMAL(18,2),
    @nDuraci INT,
    @dfeccre DATETIME,
    @ccodusu CHAR(4),
    @dFecMod DATETIME,
    @cSisOpe CHAR(15)
AS
BEGIN
    UPDATE [dbo].[SISMPRO]
    SET 
        cTipInv = @cTipInv,
        cNomPro = @cNomPro,
        cNomCor = @cNomCor,
        cFabric = @cFabric,
        cTurno = @cTurno,
        cArea = @cArea,
        cSeccio = @cSeccio,
        cGrupo = @cGrupo,
        nOrden = @nOrden,
        cEstado = @cEstado,
        nCosPro = @nCosPro,
        nPreVen = @nPreVen,
        nPreMay = @nPreMay,
        nDuraci = @nDuraci,
        dfeccre = @dfeccre,
        ccodusu = @ccodusu,
        dFecMod = @dFecMod,
        cSisOpe = @cSisOpe
    WHERE cCodPro = @cCodPro;
END;
GO
