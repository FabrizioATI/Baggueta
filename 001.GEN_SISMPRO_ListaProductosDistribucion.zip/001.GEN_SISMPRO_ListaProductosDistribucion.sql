CREATE OR ALTER PROCEDURE [dbo].[GEN_SISMPRO_ListaProductosDistribucion]
    @turno CHAR(1),  
    @grupo CHAR(2),  
    @local CHAR(3)
AS
BEGIN
    SELECT
		'001' AS CodLocalAvion,
		'002' AS CodLocalUmacollo,
		'003' AS CodLocalMetropolitano,
		'004' AS CodLocalLambramani,
		'005' AS CodLocalFeria,
		'006' AS CodLocalMarianoMelgar,
		'007' AS CodLocalSantaRosa,
		'008' AS CodLocalYanahuara,
		a.cCodPro AS CodProducto, 
		a.cArea AS Area,
		a.cSeccio AS Seccion,
		a.cGrupo AS Grupo,
		0 AS NumeroUnidad,
		a.nPreVen As Preventa,
        b.cDesCor AS NombreGrupo,  
        a.cNomCor AS NombreProducto,  
        a.nPreVen AS PRECIO,      
		0 AS CantidadLambramani,
		0 AS CantidadUmacollo,
		0 AS CantidadAvion,
		0 AS CantidadFeria,
		0 AS CantidadYanahuara,
		0 AS CantidadMetropolitano,
		0 AS CantidadMMelgar,
		0 AS CantidadSantaRosa,
        0 AS Perdida
    FROM 
        SISMPRO AS a  
        INNER JOIN SISTTAB AS b ON a.cGrupo = b.cCodigo  
    WHERE 
        b.cCodTab = '005'  
        AND b.cTipReg = 1
        AND a.cEstado = 'A'  
    ORDER BY 
        b.nOrden ASC;
END