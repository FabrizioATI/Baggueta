﻿CREATE OR ALTER PROCEDURE GEN_VENTKARD_InsertarRegistros
    @VentaKardex dbo.VentaKardexType READONLY,
    @FechaDistribucion DATE,
    @Turno CHAR(1)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT  
        CONVERT(CHAR(8), @FechaDistribucion, 112) + @Turno AS cCodKar,     
        v.Local                AS cCodLoc,                
        @Turno                 AS cTurno,          
        t.CodProducto          AS cCodPro,
        t.Area                 AS cArea,
        t.Seccion              AS cSeccio,
        t.Grupo                AS cGrupo,
        'IN'                   AS cTipReg,        
        'A'                    AS cEstReg,        
        v.Cantidad             AS nNroUni,             
        t.Preventa             AS nPreven,             
        @FechaDistribucion     AS dFecPro,   
        'A'                    AS cEstCaj,        
        NULL                   AS cLocTra,        
        NULL                   AS cCodMot,        
        NULL                   AS cUsuCaj,        
        999                    AS cCodUsu,        
        GETDATE()              AS dFecMod,
        'WINDOWS'              AS cSisOpe
    FROM @VentaKardex t
    CROSS APPLY
    (
        VALUES
            (t.CodLocalLambramani,     t.CantidadLambramani),
            (t.CodLocalUmacollo,       t.CantidadUmacollo),
            (t.CodLocalAvion,          t.CantidadAvion),
            (t.CodLocalFeria,          t.CantidadFeria),
            (t.CodLocalYanahuara,      t.CantidadYanahuara),
            (t.CodLocalMetropolitano,  t.CantidadMetropolitano),
            (t.CodLocalMarianoMelgar,  t.CantidadMMelgar),
            (t.CodLocalSantaRosa,      t.CantidadSantaRosa)
    ) v(Local, Cantidad)
END;
GO
