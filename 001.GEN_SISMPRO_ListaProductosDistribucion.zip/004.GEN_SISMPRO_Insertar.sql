CREATE OR ALTER PROCEDURE GEN_SISMPRO_Insertar
    @cCodPro CHAR(12),
    @cTipInv CHAR(1),
    @cNomPro VARCHAR(150),
    @cNomCor CHAR(25),
    @cFabric CHAR(3),
    @cTurno CHAR(1),
    @cArea CHAR(1),
    @cSeccio CHAR(1),
    @cGrupo CHAR(2),
    @nOrden INT,
    @cEstado CHAR(1),
    @nCosPro DECIMAL(18,2),
    @nPreVen DECIMAL(18,2),
    @nPreMay DECIMAL(18,2),
    @nDuraci INT,
    @dfeccre DATETIME,
    @ccodusu CHAR(4),
    @dFecMod DATETIME,
    @cSisOpe CHAR(15)
AS
BEGIN
    INSERT INTO [dbo].[SISMPRO] (
        cCodPro, cTipInv, cNomPro, cNomCor, cFabric,
        cTurno, cArea, cSeccio, cGrupo, nOrden,
        cEstado, nCosPro, nPreVen, nPreMay, nDuraci,
        dfeccre, ccodusu, dFecMod, cSisOpe
    )
    VALUES (
        @cCodPro, @cTipInv, @cNomPro, @cNomCor, @cFabric,
        @cTurno, @cArea, @cSeccio, @cGrupo, @nOrden,
        @cEstado, @nCosPro, @nPreVen, @nPreMay, @nDuraci,
        @dfeccre, @ccodusu, @dFecMod, @cSisOpe
    );
END;
GO
